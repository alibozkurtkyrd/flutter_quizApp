// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const welcome_text = 'welcome_text';
  static const enter_yourName = 'enter_yourName';
  static const start_quiz_button = 'start_quiz_button';
  static const no_photo = 'no_photo';
  static const please_take_photo = 'please_take_photo';

}
