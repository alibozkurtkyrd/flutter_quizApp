import 'dart:math';

import 'package:flutter/material.dart';

class GeneralQuestions {
  int _questionNumber = 0;

  static int totalPoint = 0;

  List<int>
      IndexChoices; // this variable store the number between 0 and 3 in shuffled order

  List<dynamic> _questionPool = [];

  GeneralQuestions() {
    // constructor
    IndexChoices = shuffleList();
  }
  //QuizPage quizPage = new QuizPage();
  void nextQuestion() {
    if (_questionNumber < _questionPool.length - 1) {
      //sleep(Duration(seconds: 1));

      _questionNumber++;
    }
  }

  bool getTurnAroundQuestion() {
    return _questionPool[_questionNumber].turnAroundQuestion;
  }

  void increaseTotalPoint() {
    // checkAnswerColor is called this function

    if (_questionPool[_questionNumber].turnAroundQuestion == false) {
      totalPoint = totalPoint + 10;
    } else {
      print("tekrar dogru cevapladıgınız soruya döndünüz");
    }
  }

  int getTotalPoint() {
    return totalPoint;
  }

  int getQuestionNumber() {
    return _questionNumber + 1;
  }

  int getLengthQuestionPool() {
    return _questionPool.length;
  }

  void previousQuestion() {
    if (_questionNumber > 0) {
      //sleep(Duration(seconds: 1));
      _questionNumber--;
    }
  }

  String getQuestionText() {
    return _questionPool[_questionNumber].questionText;
  }

  String getFirstChoices() {
    return _questionPool[_questionNumber].questionChoices[IndexChoices[0]];
  }

  String getSecondChoices() {
    return _questionPool[_questionNumber].questionChoices[IndexChoices[1]];
  }

  String getThirdChoices() {
    return _questionPool[_questionNumber].questionChoices[IndexChoices[2]];
  }

  String getFourthChoices() {
    return _questionPool[_questionNumber].questionChoices[IndexChoices[3]];
  }

  String getCorrectAnswer() {
    return _questionPool[_questionNumber].questionAnswer;
  }

  void setUserSelectedAnswer(String userAnswer) {
    // Questiondaki userSelectedAnswer a user ın sectigi cevabı verecek
    _questionPool[_questionNumber].setUserSelectedAnswer(userAnswer);
  }

  void setIsQuestionOpened() {
    _questionPool[_questionNumber].setIsQuestionOpened();
  }

  bool getIsQuestionOpened() {
    return _questionPool[_questionNumber].getIsQuestionOpened();
  }

  Color checkAnswerColor(String userSelectedAnswer, String CorrectAnswer) {
    //increaseTotalPoint();
    if (_questionPool[_questionNumber].userSelectedAnswer ==
            _questionPool[_questionNumber].questionAnswer &&
        userSelectedAnswer ==
            _questionPool[_questionNumber].userSelectedAnswer &&
        getIsQuestionOpened()) {
      increaseTotalPoint();

      _questionPool[_questionNumber].turnAroundQuestion = true;
      // print("if durumu");
      return Colors.green;
    } else if (userSelectedAnswer == CorrectAnswer &&
        getIsQuestionOpened()) // bu duruma göre dogru cevap her zaman yanacak
    {
      // print("else if durumu yesil yanmamsıa gerekli durum");
      return Colors.green;
    } else if (userSelectedAnswer ==
            _questionPool[_questionNumber].userSelectedAnswer &&
        getIsQuestionOpened()) {
      // print("else if 2 durum yani hatalı durum");
      //checkAnswerColor(_questionPool[_questionNumber].questionAnswer); // bu yesil yanması icin ama calısmadı
      return Colors.red;
    } else {
      return Colors.grey;
    }
  }

  List<int> shuffleList() {
    // this function shuffle the list containing number between 0-3
    // we want to shuffle the questions' choices
    List<int> numbers = [0, 1, 2, 3];
    var random = new Random();

    for (int i = 0; i < 4; i++) {
      int n = random.nextInt(i + 1);
      int temp = numbers[i];
      numbers[i] = numbers[n];
      numbers[n] = temp;
    }

    return numbers;
  }
}
